# HemaCheck — Prototipe Web Skrining Awal Anemia

## Cara menjalankan
1. Ekstrak folder/ZIP.
2. Buka `index.html` di browser.
3. Isi 12 pertanyaan.
4. Pilih foto dari galeri atau gunakan kamera.
5. Klik Analisis Skrining.

## Catatan penting
Bagian analisis citra pada versi ini adalah SIMULASI untuk prototipe UI. Skor visual sengaja diturunkan dari skor survei sehingga demo dapat berjalan tanpa backend/model AI.

Untuk penelitian/PKM yang nyata, bagian `analyze()` harus diganti dengan model computer vision yang dilatih dan divalidasi menggunakan dataset konjungtiva yang sesuai, serta diuji terhadap pemeriksaan klinis/laboratorium. Jangan menyebut output prototipe ini sebagai diagnosis anemia.

## Struktur
- index.html — struktur halaman
- style.css — desain/responsif
- script.js — survei, kamera, upload, simulasi analisis, rekomendasi
- assets/heart.svg — ikon
- assets/eye.svg — ilustrasi konjungtiva
